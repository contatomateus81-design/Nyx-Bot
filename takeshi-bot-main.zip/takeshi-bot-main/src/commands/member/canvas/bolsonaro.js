import fs from "node:fs";
import { PREFIX } from "../../../config.js";
import { DangerError, InvalidParameterError } from "../../../errors/index.js";
import { upload } from "../../../services/linker.js";
import { canvas } from "../../../services/spider-x-api.js";
import { getRandomNumber } from "../../../utils/index.js";

export default {
  name: "bolsonaro",
  description: "Gero uma montagem do Bolsonaro com a imagem que você enviar",
  commands: ["bolsonaro"],
  usage: `${PREFIX}bolsonaro (marque a imagem) ou ${PREFIX}bolsonaro (responda a imagem)`,
  /**
   * @param {CommandHandleProps} props
   */
  handle: async ({
    isImage,
    downloadImage,
    sendSuccessReact,
    sendWaitReact,
    sendImageFromURL,
    sendErrorReply,
    webMessage,
  }) => {
    if (!isImage) {
      throw new InvalidParameterError(
        "Você precisa marcar uma imagem ou responder a uma imagem"
      );
    }

    await sendWaitReact();

    const fileName = getRandomNumber(10_000, 99_999).toString();
    const filePath = await downloadImage(webMessage, fileName);
    const buffer = fs.readFileSync(filePath);
    const link = await upload(buffer, `${fileName}.png`);
    if (!link) {
      throw new DangerError(
        "Não consegui fazer o upload da imagem, tente novamente mais tarde!"
      );
    }
    const url = canvas("bolsonaro", link);
    const response = await fetch(url);
    if (!response.ok) {
      const data = await response.json();
      await sendErrorReply(
        `Ocorreu um erro ao executar uma chamada remota para a Spider X API no comando bolsonaro!
      
📄 *Detalhes*: ${data.message}`
      );
      return;
    }
    await sendSuccessReact();
    await sendImageFromURL(url, "Imagem gerada!");
    fs.unlinkSync(filePath);
  },
};
